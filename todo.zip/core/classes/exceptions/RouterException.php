<?php
/**
 * Created by PhpStorm.
 * User: asus
 * Date: 21.03.2018
 * Time: 12:42
 */

class RouterException extends Exception{

}
class RouterIncorrectUri extends RouterException{

}