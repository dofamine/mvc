<?php
/**
 * Created by PhpStorm.
 * User: asus
 * Date: 09.04.2018
 * Time: 14:23
 */
return [
  "passHasher"=>[
      "salt_len"=>5,
      "salt_pos"=>10,
      "alg"=>"sha256"
  ]
];