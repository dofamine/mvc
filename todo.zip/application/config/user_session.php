<?php
/**
 * Created by PhpStorm.
 * User: asus
 * Date: 09.04.2018
 * Time: 15:54
 */
return [
  "short"=>3600,
  "long"=>3600*24*30
];