<?php
return [
  "login"=>"root",
  "pass"=>"",
  "dbname"=>"todo",
  "charset"=>"utf8",
  "host"=>"127.0.0.1"
];